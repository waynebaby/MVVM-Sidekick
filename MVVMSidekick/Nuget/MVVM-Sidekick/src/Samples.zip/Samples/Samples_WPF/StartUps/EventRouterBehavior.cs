﻿using System.Reactive;
using System.Reactive.Linq;
using MVVMSidekick.ViewModels;
using MVVMSidekick.Views;
using MVVMSidekick.Reactive;
using MVVMSidekick.Services;
using MVVMSidekick.Commands;
using Samples.ViewModels;
using System;
using System.Net;
using System.Windows;
using System.Threading.Tasks;


namespace Samples.Startups
{
    public static partial class StartupFunctions
    {
        public static async void ConfigEventRouterBehavior()
        {
            ViewModelLocator<EventRouterBehavior_Model>
                .Instance
                .Register(new EventRouterBehavior_Model())
                .GetViewMapper()
                .MapToDefault<EventRouterBehavior>();
        
        }
    }
}
